import { serve } from "https://deno.land/std/http/server.ts"
import { createClient } from "https://esm.sh/@supabase/supabase-js@2"

serve(async (req) => {
  try {
    const data = await req.json()

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    )

    const fileName = `${data.mobile_number}_${data.plan_type}_diet_plan.pdf`
    const RENDER_URL = "https://khana-pdf-generator-web-service.onrender.com"

    // ============================
    // PDF GENERATION WITH RETRY
    // ============================
    async function generatePDFWithRetry() {

      // 🔥 1. Wake Render
      for (let i = 0; i < 5; i++) {
        try {
          const res = await fetch(`${RENDER_URL}/health`)
          if (res.ok) break
        } catch {}
        await new Promise(r => setTimeout(r, 2000)) // ✅ fixed
      }

      // 🔥 2. Retry PDF call
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          const controller = new AbortController()
          const timeout = setTimeout(() => controller.abort(), 20000)

          const pdfResponse = await fetch(
            `${RENDER_URL}/generate-pdf`,
            {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(data),
              signal: controller.signal,
            }
          ).finally(() => clearTimeout(timeout))

          if (!pdfResponse.ok) {
            const text = await pdfResponse.text()
            throw new Error(`Render error: ${text}`)
          }

          const pdf = await pdfResponse.arrayBuffer()

          // ============================
          // STORE
          // ============================
          const plan = data.plan_type.split("_")[0]
          const path = `${plan}/${data.plan_type}/${fileName}`

          const { error } = await supabase.storage
            .from("khanaplan_pdfs")
            .upload(path, pdf, {
              contentType: "application/pdf",
              upsert: true
            })

          if (error) throw error

          const { data: signedUrlData, error: signedUrlError } =
            await supabase.storage
              .from("khanaplan_pdfs")
              .createSignedUrl(path, 60 * 60 * 24)

          if (signedUrlError) {
            throw new Error(`Signed URL error: ${signedUrlError.message}`)
          }

          // ✅ SUCCESS
          return signedUrlData

        } catch (err) {
          if (attempt === 2) throw err
          await new Promise(r => setTimeout(r, 3000))
        }
      }
    }

    // ============================
    // CALL RETRY FUNCTION
    // ============================
    const result = await generatePDFWithRetry()

    // ============================
    // SEND EMAIL
    // ============================
    await fetch("https://api.brevo.com/v3/smtp/email", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "api-key": Deno.env.get("Supa_Brevo_Email_APIKey")!
      },
      body: JSON.stringify({
        sender: {
          name: "Khana Plan",
          email: "khanaplan.orders@gmail.com"
        },
        to: [
          {
            email: data.email,
            name: data.customer_name
          }
        ],
        subject: "Your Diet Plan is Ready",
        htmlContent: `
          <p>Hi ${data.customer_name},</p>
          <p>Your personalized diet plan is ready.</p>
          <p><a href="${result.signedUrl}">Download your PDF</a></p>
          <p>Thanks,<br>Khana Plan</p>
        `
      })
    })

    // ============================
    // RESPONSE
    // ============================
    return new Response(
      JSON.stringify({
        success: true,
        pdf_url: result.signedUrl
      }),
      { headers: { "Content-Type": "application/json" } }
    )

  } catch (err) {
    return new Response(
      JSON.stringify({
        error: err instanceof Error ? err.message : String(err)
      }),
      { headers: { "Content-Type": "application/json" }, status: 500 }
    )
  }
})