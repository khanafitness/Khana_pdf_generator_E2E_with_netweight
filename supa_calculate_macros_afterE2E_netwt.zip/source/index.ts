import { serve } from "https://deno.land/std@0.224.0/http/server.ts"

type Input = {
  plan_type: string;
  mobile_number: string;
  customer_name: string;
  email: string;
  target_calories: number
  target_protein: number
  target_carbs?: number
  target_fat?: number

  protein_split?: {
    breakfast: number
    lunch: number
    dinner: number
  }

  calorie_split?: {
    breakfast: number
    lunch: number
    dinner: number
  }
}

function roundMacros(value: number, type?: "protein" | "carbs" | "fat") {
  if (type === "protein") return Math.round(value)
  return Math.round(value / 5) * 5
}

function validateSplit(split: { breakfast: number; lunch: number; dinner: number }) {
  const total = split.breakfast + split.lunch + split.dinner
  return Math.abs(total - 100) < 0.01
}

// ─── Supabase Function URLs ───────────────────────────────────────────────────
// These are resolved at runtime from env vars so you never hard-code URLs.
function getPlaceholderUrl(): string {
  const base = Deno.env.get("SUPABASE_URL")!                          // e.g. https://xyz.supabase.co
  return `${base}/functions/v1/supa_calculate_placeholder_qty`
}

function getPdfEmailUrl(): string {
  const base = Deno.env.get("SUPABASE_URL")!
  return `${base}/functions/v1/supa_generate_diet_pdfEmail`
}

// The service-role key is used for internal function-to-function calls
function getServiceRoleKey(): string {
  return Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
}

// ─── Main Handler ─────────────────────────────────────────────────────────────

serve(async (req) => {

  const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  }

  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders })
  }

  try {
    if (req.method !== "POST") {
      return new Response(
        JSON.stringify({ error: "Method not allowed. Use POST." }),
        { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      )
    }

    const body: Input = await req.json()

    const {
      plan_type,
      mobile_number,
      email,
      customer_name,
      target_calories,
      target_protein,
      target_carbs,
      target_fat,
      protein_split = { breakfast: 25, lunch: 35, dinner: 40 },
      calorie_split = { breakfast: 25, lunch: 35, dinner: 40 },
    } = body

    // ── Validation ──────────────────────────────────────────────────────────
    if (!target_calories || !target_protein) {
      return new Response(
        JSON.stringify({ error: "target_calories and target_protein are required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      )
    }

    if (!validateSplit(protein_split)) {
      return new Response(
        JSON.stringify({ error: "protein_split must total 100" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      )
    }

    if (!validateSplit(calorie_split)) {
      return new Response(
        JSON.stringify({ error: "calorie_split must total 100" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      )
    }

    // ── Step 1: Calculate macros ────────────────────────────────────────────
    const proteinCalories = target_protein * 4

    let finalCarbs = target_carbs ?? 0
    let finalFat   = target_fat   ?? 0

    if (target_carbs == null && target_fat == null) {
      const remaining  = target_calories - proteinCalories
      finalCarbs = (remaining * 0.6) / 4
      finalFat   = (remaining * 0.4) / 9
    } else if (target_carbs != null && target_fat == null) {
      const remaining = target_calories - proteinCalories - target_carbs * 4
      finalFat = remaining / 9
    } else if (target_carbs == null && target_fat != null) {
      const remaining = target_calories - proteinCalories - target_fat * 9
      finalCarbs = remaining / 4
    }

    if (finalCarbs < 0 || finalFat < 0) {
      return new Response(
        JSON.stringify({ error: "Calculated carbs or fat became negative. Check input values." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      )
    }

    const meals = (["breakfast", "lunch", "dinner"] as const).map((meal) => ({
      meal,
      calories:   roundMacros(target_calories * (calorie_split[meal] / 100)),
      protein_g:  roundMacros(target_protein  * (protein_split[meal] / 100), "protein"),
      carbs_g:    roundMacros(finalCarbs       * (calorie_split[meal] / 100)),
      fat_g:      roundMacros(finalFat          * (calorie_split[meal] / 100)),
    }))

    // This is the full output of supa_calculate_macros
    const macrosOutput = {
      success: true,
      plan_type,
      mobile_number,
      email,
      customer_name,
      input: {
        target_calories,
        target_protein,
        target_carbs: roundMacros(finalCarbs),
        target_fat:   roundMacros(finalFat),
      },
      splits: { protein_split, calorie_split },
      meals,
    }

    // ── Step 2: Call supa_calculate_placeholder_qty ─────────────────────────
    // Pass only what that function expects: customer info + input + meals
    const placeholderPayload = {
      plan_type,
      mobile_number,
      customer_name,
      email,
      input:  macrosOutput.input,
      meals:  macrosOutput.meals,
    }

    const placeholderRes = await fetch(getPlaceholderUrl(), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(placeholderPayload),
    })

    if (!placeholderRes.ok) {
      const text = await placeholderRes.text()
      throw new Error(`supa_calculate_placeholder_qty failed: ${text}`)
    }

    const placeholderOutput = await placeholderRes.json()

    if (!placeholderOutput.success) {
      throw new Error(`supa_calculate_placeholder_qty error: ${placeholderOutput.error}`)
    }

    // ── Step 3: Call supa_generate_diet_pdfEmail ────────────────────────────
    // The placeholder output already contains everything pdfEmail needs
    const pdfEmailRes = await fetch(getPdfEmailUrl(), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(placeholderOutput),
    })

    if (!pdfEmailRes.ok) {
      const text = await pdfEmailRes.text()
      throw new Error(`supa_generate_diet_pdfEmail failed: ${text}`)
    }

    const pdfEmailOutput = await pdfEmailRes.json()

    if (!pdfEmailOutput.success) {
      throw new Error(`supa_generate_diet_pdfEmail error: ${pdfEmailOutput.error}`)
    }

    // ── Final response back to the website ──────────────────────────────────
    return new Response(
      JSON.stringify({
        success:  true,
        pdf_url:  pdfEmailOutput.pdf_url,
        // Optional: include intermediate outputs for debugging
        // macros:      macrosOutput,
        // quantities:  placeholderOutput,
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    )

  } catch (error) {
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    )
  }
})
