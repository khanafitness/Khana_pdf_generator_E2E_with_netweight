// supa_calculate_placeholder_qty
// Supabase Edge Function — calculates food quantities for all 4 diet plan types:
//   pcos_nonveg, pcos_veg, basic_nonveg, basic_veg

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// ─── Types ───────────────────────────────────────────────────────────────────

interface MacroInput {
  target_calories: number;
  target_protein: number;
  target_carbs: number;
  target_fat: number;
}

interface MealMacros {
  meal: string;
  calories: number;
  protein_g: number;
  carbs_g: number;
  fat_g: number;
}

interface RequestBody {
  plan_type: string;
  mobile_number: string;
  customer_name: string;
  email: string;
  input: MacroInput;
  meals: MealMacros[];
}

interface FoodItem {
  food_id: string;
  food_name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  serving_quantity: number;
  serving_unit: string;
  net_wt_gm: number;
  food_state: string;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function roundToHalf(value: number): number {
  return Math.round(value * 2) / 2;
}

function roundTo(value: number, step: number): number {
  return Math.round(value / step) * step;
}

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

function calculateOilSplit(totalCalories: number): {
  oil_b: number;
  oil_l: number;
  oil_d: number;
  total: number;
} {
  const total = clamp(Math.round(totalCalories / 270), 4, 8);
  const oil_b = 1;
  const oil_d = Math.max(2, Math.round((total - oil_b) * 0.55));
  const oil_l = total - oil_b - oil_d;
  return { oil_b, oil_l, oil_d, total };
}

// ─── Core Calculation: PCOS Non-Veg ──────────────────────────────────────────

function calcPcosNonVeg(
  meals: MealMacros[],
  foods: Record<string, FoodItem>
): Record<string, string> {
  const B = meals.find((m) => m.meal === "breakfast")!;
  const L = meals.find((m) => m.meal === "lunch")!;
  const D = meals.find((m) => m.meal === "dinner")!;
  const totalCal = B.calories + L.calories + D.calories;

  const { oil_b, oil_l, oil_d, total: total_oil } = calculateOilSplit(totalCal);
  const OIL_CAL_PER_TSP = foods["oil"].calories;

  const b_cal_net = B.calories - oil_b * OIL_CAL_PER_TSP;
  const l_cal_net = L.calories - oil_l * OIL_CAL_PER_TSP;
  const d_cal_net = D.calories - oil_d * OIL_CAL_PER_TSP;

  // ── BREAKFAST ───────────────────────────────────────────────────────────────
  const curd           = foods["curd"];
  const besan_chilla   = foods["besan_chilla"];
  const g_moong_chilla = foods["g_moong_chilla"];
  const egg            = foods["egg"];
  const sourdough      = foods["sourdough_bread"];
  const oats           = foods["oats_cooked"];
  const ragi_chilla    = foods["ragi_chilla"];
  const paneer         = foods["paneer"];
  const tofu           = foods["tofu_raw"];
  const dalia_khichadi = foods["dalia_khichadi"];
  const millet_upma    = foods["millet_upma"];

  const CURD_CAL  = curd.calories;
  const CURD_PROT = curd.protein;

  const paneer_prot_per_g = paneer.protein / paneer.serving_quantity;
  const paneer_cal_per_g  = paneer.calories / paneer.serving_quantity;
  const tofu_prot_per_g   = tofu.protein / tofu.serving_quantity;
  const tofu_cal_per_g    = tofu.calories / tofu.serving_quantity;

  const b_cal_after_curd  = b_cal_net - CURD_CAL;
  const b_prot_after_curd = B.protein_g - CURD_PROT;

  const besan_pieces  = clamp(Math.round(b_cal_after_curd / besan_chilla.calories), 1, 4);
  const nw_besan      = besan_pieces * besan_chilla.net_wt_gm;

  const gmoong_pieces = clamp(Math.round(b_cal_after_curd / g_moong_chilla.calories), 1, 4);
  const nw_gmoong     = gmoong_pieces * g_moong_chilla.net_wt_gm;

  const egg_qty = clamp(Math.round(B.protein_g / egg.protein), 2, 4);

  const sour_remaining = b_cal_net - egg_qty * egg.calories;
  const sour_bread     = clamp(Math.round(sour_remaining / sourdough.calories), 1, 3);

  const oats_after_egg = b_cal_net - 1 * egg.calories;
  const nw_oats = clamp(
    roundTo(oats_after_egg / (oats.calories / oats.net_wt_gm), 10),
    oats.net_wt_gm * 0.5,
    oats.net_wt_gm * 2
  );

  const b_paneer_qty = clamp(
    roundTo(Math.max(0, b_prot_after_curd) / paneer_prot_per_g, 10),
    30, 100
  );
  const b_tofu_qty = clamp(
    roundTo(Math.max(0, b_prot_after_curd) / tofu_prot_per_g, 10),
    30, 100
  );

  const ragi_after_paneer = b_cal_after_curd - b_paneer_qty * paneer_cal_per_g;
  const ragi_pieces = clamp(Math.round(Math.max(1, ragi_after_paneer / ragi_chilla.calories)), 1, 4);
  const nw_ragi     = ragi_pieces * ragi_chilla.net_wt_gm;

  const dalia_cal_avail = b_cal_net - b_paneer_qty * paneer_cal_per_g;
  const dalia_veg_qty   = clamp(roundToHalf(dalia_cal_avail / dalia_khichadi.calories), 0.5, 3);
  const nw_dalia_veg    = Math.round(dalia_veg_qty * dalia_khichadi.net_wt_gm);

  const milet_upma_qty  = clamp(roundToHalf(dalia_cal_avail / millet_upma.calories), 0.5, 3);
  const nw_milet_upma   = Math.round(milet_upma_qty * millet_upma.net_wt_gm);

  // ── LUNCH ───────────────────────────────────────────────────────────────────
  const brown_rice = foods["brown_rice"];
  const rajma      = foods["rajma_cooked"];
  const chhole     = foods["chhole_cooked"];
  const dal        = foods["dal"];
  const sabzi      = foods["sabzi_cooked"];
  const chicken    = foods["chicken"];
  const kala_chana = foods["kala_chana"];

  const SABZI_CAL  = sabzi.calories * 2;
  const SABZI_PROT = sabzi.protein * 2;

  const l_cal_fixed  = CURD_CAL + SABZI_CAL;
  const l_prot_fixed = CURD_PROT + SABZI_PROT;
  const l_cal_avail  = l_cal_net - l_cal_fixed;
  const l_prot_avail = L.protein_g - l_prot_fixed;

  const chicken_cal_per_g  = chicken.calories / chicken.serving_quantity;
  const chicken_prot_per_g = chicken.protein  / chicken.serving_quantity;

  const L_nw_chicken = clamp(roundTo(l_prot_avail / chicken_prot_per_g, 10), 60, 200);
  const l_rice_after_chicken = l_cal_avail - L_nw_chicken * chicken_cal_per_g;
  const L_brice_chicken = Math.max(0.5, roundToHalf(l_rice_after_chicken / brown_rice.calories));

  const L_nw_paneer = clamp(roundTo(l_prot_avail / paneer_prot_per_g, 10), 60, 200);
  const l_rice_after_paneer = l_cal_avail - L_nw_paneer * paneer_cal_per_g;
  const L_brice_paneer = Math.max(0.5, roundToHalf(l_rice_after_paneer / brown_rice.calories));

  const L_nw_tofu = clamp(roundTo(l_prot_avail / tofu_prot_per_g, 10), 60, 200);

  const rajma_cups_l = Math.max(0.5, roundToHalf(l_prot_avail / rajma.protein));
  const L_rajma_qty  = rajma_cups_l;
  const L_nw_rajma   = Math.round(rajma_cups_l * rajma.net_wt_gm);
  const l_rice_after_rajma = l_cal_avail - rajma_cups_l * rajma.calories;
  const L_brice_rajma = Math.max(0.5, roundToHalf(l_rice_after_rajma / brown_rice.calories));

  const chhole_cups_l = Math.max(0.5, roundToHalf(l_prot_avail / chhole.protein));
  const L_chhole_qty  = chhole_cups_l;
  const L_nw_chhole   = Math.round(chhole_cups_l * chhole.net_wt_gm);

  const dal_cups_l = Math.max(0.5, roundToHalf(l_prot_avail / dal.protein));
  const L_dal_qty  = dal_cups_l;
  const L_nw_dal   = Math.round(dal_cups_l * dal.net_wt_gm);

  const kchana_cups_l = Math.max(0.5, roundToHalf(l_prot_avail / kala_chana.protein));
  const L_kchana_qty  = kchana_cups_l;
  const L_nw_kchana   = Math.round(kchana_cups_l * (kala_chana.serving_quantity > 0 ? kala_chana.serving_quantity : 150));

  const L_brice_qty = Math.max(0.5, roundToHalf((L_brice_chicken + L_brice_paneer + L_brice_rajma) / 3));
  const L_nw_brice  = Math.round(L_brice_qty * brown_rice.net_wt_gm);

  // ── DINNER ──────────────────────────────────────────────────────────────────
  const jowar_roti = foods["jowar_roti"];

  const d_cal_fixed  = CURD_CAL + SABZI_CAL;
  const d_prot_fixed = CURD_PROT + SABZI_PROT;
  const d_cal_avail  = d_cal_net - d_cal_fixed;
  const d_prot_avail = D.protein_g - d_prot_fixed;

  const d_jowar_roti_qty =
    totalCal <= 1200 ? 1 :
    totalCal <= 1600 ? 2 : 3;
  const d_nw_jowar_roti = d_jowar_roti_qty * jowar_roti.net_wt_gm;

  const roti_cal  = d_jowar_roti_qty * jowar_roti.calories;
  const roti_prot = d_jowar_roti_qty * jowar_roti.protein;
  const d_cal_after_roti  = d_cal_avail - roti_cal;
  const d_prot_after_roti = d_prot_avail - roti_prot;

  const d_nw_chicken = clamp(roundTo(Math.max(60, d_prot_after_roti / chicken_prot_per_g), 10), 60, 200);
  const d_rice_after_chicken = d_cal_after_roti - d_nw_chicken * chicken_cal_per_g;
  const d_brice_chicken = Math.max(0.5, roundToHalf(d_rice_after_chicken / brown_rice.calories));

  const d_nw_paneer = clamp(roundTo(Math.max(60, d_prot_after_roti / paneer_prot_per_g), 10), 60, 200);
  const d_rice_after_paneer = d_cal_after_roti - d_nw_paneer * paneer_cal_per_g;
  const d_brice_paneer = Math.max(0.5, roundToHalf(d_rice_after_paneer / brown_rice.calories));

  const d_nw_tofu = clamp(roundTo(Math.max(60, d_prot_after_roti / tofu_prot_per_g), 10), 60, 200);

  const rajma_cups_d = Math.max(0.5, roundToHalf(d_prot_after_roti / rajma.protein));
  const d_rajma_qty  = rajma_cups_d;
  const d_nw_rajma   = Math.round(rajma_cups_d * rajma.net_wt_gm);
  const d_rice_after_rajma = d_cal_after_roti - rajma_cups_d * rajma.calories;
  const d_brice_rajma = Math.max(0.5, roundToHalf(d_rice_after_rajma / brown_rice.calories));

  const chhole_cups_d = Math.max(0.5, roundToHalf(d_prot_after_roti / chhole.protein));
  const d_chhole_qty  = chhole_cups_d;
  const d_nw_chhole   = Math.round(chhole_cups_d * chhole.net_wt_gm);

  const dal_cups_d = Math.max(0.5, roundToHalf(d_prot_after_roti / dal.protein));
  const d_dal_qty  = dal_cups_d;
  const d_nw_dal   = Math.round(dal_cups_d * dal.net_wt_gm);

  const kchana_cups_d = Math.max(0.5, roundToHalf(d_prot_after_roti / kala_chana.protein));
  const d_kchana_qty  = kchana_cups_d;
  const d_nw_kchana   = Math.round(kchana_cups_d * (kala_chana.serving_quantity > 0 ? kala_chana.serving_quantity : 150));

  const d_brice_qty = Math.max(0.5, roundToHalf((d_brice_chicken + d_brice_paneer + d_brice_rajma) / 3));
  const d_nw_brice  = Math.round(d_brice_qty * brown_rice.net_wt_gm);

  return {
    besan_qty:           String(besan_pieces),
    nw_besan_qty:        String(nw_besan),
    gmoong_qty:          String(gmoong_pieces),
    nw_gmoong_qty:       String(nw_gmoong),
    egg_qty:             String(egg_qty),
    nw_oats_qty:         String(nw_oats),
    sour_bread:          String(sour_bread),
    b_paneer_qty:        String(b_paneer_qty),
    b_tofu_qty:          String(b_tofu_qty),
    ragi_qty:            String(ragi_pieces),
    nw_ragi_qty:         String(nw_ragi),
    dalia_veg_qty:       String(dalia_veg_qty),
    nw_dalia_veg_qty:    String(nw_dalia_veg),
    milet_upma_qty:      String(milet_upma_qty),
    nw_milet_upma_qty:   String(nw_milet_upma),
    curd_qty:            "1",
    L_brice_qty:         String(L_brice_qty),
    L_nw_brice_qty:      String(L_nw_brice),
    L_rajma_qty:         String(L_rajma_qty),
    L_nw_rajma_qty:      String(L_nw_rajma),
    L_chhole_qty:        String(L_chhole_qty),
    L_nw_chhole_qty:     String(L_nw_chhole),
    L_dal_qty:           String(L_dal_qty),
    L_nw_dal_qty:        String(L_nw_dal),
    L_nw_chicken_qty:    String(L_nw_chicken),
    L_nw_paneer_qty:     String(L_nw_paneer),
    L_nw_tofu_qty:       String(L_nw_tofu),
    L_kchana_qty:        String(L_kchana_qty),
    L_nw_kchana_qty:     String(L_nw_kchana),
    sabzi_qty:           "2",
    d_jowar_roti_qty:    String(d_jowar_roti_qty),
    d_nw_jowar_roti_qty: String(d_nw_jowar_roti),
    d_brice_qty:         String(d_brice_qty),
    d_nw_brice_qty:      String(d_nw_brice),
    d_rajma_qty:         String(d_rajma_qty),
    d_nw_rajma_qty:      String(d_nw_rajma),
    d_chhole_qty:        String(d_chhole_qty),
    d_nw_chhole_qty:     String(d_nw_chhole),
    d_dal_qty:           String(d_dal_qty),
    d_nw_dal_qty:        String(d_nw_dal),
    d_nw_chicken_qty:    String(d_nw_chicken),
    d_nw_paneer_qty:     String(d_nw_paneer),
    d_nw_tofu_qty:       String(d_nw_tofu),
    d_kchana_qty:        String(d_kchana_qty),
    d_nw_kchana_qty:     String(d_nw_kchana),
    Oil_qty_b:           String(oil_b),
    Oil_qty_l:           String(oil_l),
    Oil_qty_d:           String(oil_d),
    total_qty_oil:       String(total_oil),
  };
}

// ─── Core Calculation: PCOS Veg ───────────────────────────────────────────────

function calcPcosVeg(
  meals: MealMacros[],
  foods: Record<string, FoodItem>
): Record<string, string> {
  // calcPcosNonVeg is safe here because REQUIRED_FOODS["pcos_veg"] includes
  // both "tofu_raw" and "chicken" so foods[...] lookups inside it won't crash.
  const base = calcPcosNonVeg(meals, foods);

  const B = meals.find((m) => m.meal === "breakfast")!;
  const L = meals.find((m) => m.meal === "lunch")!;
  const D = meals.find((m) => m.meal === "dinner")!;
  const totalCal = B.calories + L.calories + D.calories;

  const { oil_l, oil_d } = calculateOilSplit(totalCal);
  const OIL_CAL_PER_TSP = foods["oil"].calories;

  const l_cal_net = L.calories - oil_l * OIL_CAL_PER_TSP;
  const d_cal_net = D.calories - oil_d * OIL_CAL_PER_TSP;

  const curd       = foods["curd"];
  const paneer     = foods["paneer"];
  const tofu       = foods["tofu_raw"];
  const sabzi      = foods["sabzi_cooked"];
  const brown_rice = foods["brown_rice"];
  const jowar_roti = foods["jowar_roti"];
  const rajma      = foods["rajma_cooked"];

  const CURD_CAL  = curd.calories;
  const CURD_PROT = curd.protein;
  const SABZI_CAL  = sabzi.calories * 2;
  const SABZI_PROT = sabzi.protein * 2;

  const paneer_cal_per_g = paneer.calories / paneer.serving_quantity;
  const tofu_prot_per_g  = tofu.protein / tofu.serving_quantity;
  const tofu_cal_per_g   = tofu.calories / tofu.serving_quantity;

  // ── Lunch ────────────────────────────────────────────────────────────────────
  const l_cal_fixed  = CURD_CAL + SABZI_CAL;
  const l_prot_fixed = CURD_PROT + SABZI_PROT;
  const l_cal_avail  = l_cal_net - l_cal_fixed;
  const l_prot_avail = L.protein_g - l_prot_fixed;

  const L_nw_tofu = clamp(roundTo(l_prot_avail / tofu_prot_per_g, 10), 60, 200);
  const l_rice_after_tofu = l_cal_avail - L_nw_tofu * tofu_cal_per_g;
  const L_brice_tofu = Math.max(0.5, roundToHalf(l_rice_after_tofu / brown_rice.calories));

  // Average rice: tofu day + 2 × base average (covers paneer+rajma days)
  const L_brice_qty_veg = Math.max(0.5, roundToHalf(
    (L_brice_tofu + parseFloat(base.L_brice_qty) + parseFloat(base.L_brice_qty)) / 3
  ));
  const L_nw_brice_veg = Math.round(L_brice_qty_veg * brown_rice.net_wt_gm);

  // pcos_veg template uses {{L_paneer_qty}} — same gram value as L_nw_paneer_qty
  const L_paneer_qty_grams = parseFloat(base.L_nw_paneer_qty);

  // ── Dinner ───────────────────────────────────────────────────────────────────
  const d_cal_fixed  = CURD_CAL + SABZI_CAL;
  const d_prot_fixed = CURD_PROT + SABZI_PROT;
  const d_cal_avail  = d_cal_net - d_cal_fixed;
  const d_prot_avail = D.protein_g - d_prot_fixed;

  const d_jowar_roti_qty =
    totalCal <= 1200 ? 1 :
    totalCal <= 1600 ? 2 : 3;
  const roti_cal  = d_jowar_roti_qty * jowar_roti.calories;
  const roti_prot = d_jowar_roti_qty * jowar_roti.protein;
  const d_cal_after_roti  = d_cal_avail - roti_cal;
  const d_prot_after_roti = d_prot_avail - roti_prot;

  const d_nw_tofu = clamp(roundTo(Math.max(60, d_prot_after_roti / tofu_prot_per_g), 10), 60, 200);
  const d_rice_after_tofu = d_cal_after_roti - d_nw_tofu * tofu_cal_per_g;
  const d_brice_tofu = Math.max(0.5, roundToHalf(d_rice_after_tofu / brown_rice.calories));

  const d_brice_paneer = Math.max(0.5, roundToHalf(
    (d_cal_after_roti - parseFloat(base.d_nw_paneer_qty) * paneer_cal_per_g) / brown_rice.calories
  ));
  const d_brice_rajma = Math.max(0.5, roundToHalf(
    (d_cal_after_roti - parseFloat(base.d_rajma_qty) * rajma.calories) / brown_rice.calories
  ));
  const d_brice_qty_veg = Math.max(0.5, roundToHalf((d_brice_tofu + d_brice_paneer + d_brice_rajma) / 3));
  const d_nw_brice_veg  = Math.round(d_brice_qty_veg * brown_rice.net_wt_gm);

  return {
    ...base,
    L_paneer_qty:     String(L_paneer_qty_grams),
    L_nw_tofu_qty:    String(L_nw_tofu),
    L_brice_qty:      String(L_brice_qty_veg),
    L_nw_brice_qty:   String(L_nw_brice_veg),
    d_nw_tofu_qty:    String(d_nw_tofu),
    d_brice_qty:      String(d_brice_qty_veg),
    d_nw_brice_qty:   String(d_nw_brice_veg),
    // Zero out chicken/egg for veg plan
    L_nw_chicken_qty: "0",
    d_nw_chicken_qty: "0",
    egg_qty:          "0",
    sour_bread:       "0",
  };
}

// ─── Core Calculation: Basic Non-Veg ─────────────────────────────────────────

function calcBasicNonVeg(
  meals: MealMacros[],
  foods: Record<string, FoodItem>
): Record<string, string> {
  const B = meals.find((m) => m.meal === "breakfast")!;
  const L = meals.find((m) => m.meal === "lunch")!;
  const D = meals.find((m) => m.meal === "dinner")!;
  const totalCal = B.calories + L.calories + D.calories;

  const { oil_b, oil_l, oil_d, total: total_oil } = calculateOilSplit(totalCal);
  const OIL_CAL_PER_TSP = foods["oil"].calories;

  const b_cal_net = B.calories - oil_b * OIL_CAL_PER_TSP;
  const l_cal_net = L.calories - oil_l * OIL_CAL_PER_TSP;
  const d_cal_net = D.calories - oil_d * OIL_CAL_PER_TSP;

  const curd           = foods["curd"];
  const paneer         = foods["paneer"];
  const tofu           = foods["tofu_raw"];
  const chicken        = foods["chicken"];
  const white_rice     = foods["white_rice"];
  const wheat_roti     = foods["wheat_roti"];
  const besan_chilla   = foods["besan_chilla"];
  const g_moong_chilla = foods["g_moong_chilla"];
  const egg            = foods["egg"];
  const suji_upma      = foods["suji_upma"];
  const oats_cooked    = foods["oats_cooked"];
  const rajma          = foods["rajma_cooked"];
  const chhole         = foods["chhole_cooked"];
  const dal            = foods["dal"];
  const kala_chana     = foods["kala_chana"];
  const sabzi          = foods["sabzi_cooked"];
  const dalia_khichadi = foods["dalia_khichadi"];
  const ragi_chilla    = foods["ragi_chilla"];


  const CURD_CAL  = curd.calories;
  const CURD_PROT = curd.protein;
  const SABZI_CAL  = sabzi.calories * 2;
  const SABZI_PROT = sabzi.protein * 2;

  const paneer_prot_per_g = paneer.protein / paneer.serving_quantity;
  const paneer_cal_per_g  = paneer.calories / paneer.serving_quantity;
  const tofu_prot_per_g   = tofu.protein / tofu.serving_quantity;
  const tofu_cal_per_g    = tofu.calories / tofu.serving_quantity;

  // ── BREAKFAST ───────────────────────────────────────────────────────────────
  const b_cal_after_curd  = b_cal_net - CURD_CAL;
  const b_prot_after_curd = B.protein_g - CURD_PROT;

  const besan_pieces  = clamp(Math.round(b_cal_after_curd / besan_chilla.calories), 1, 4);
  const nw_besan      = besan_pieces * besan_chilla.net_wt_gm;

  const gmoong_pieces = clamp(Math.round(b_cal_after_curd / g_moong_chilla.calories), 1, 4);
  const nw_gmoong     = gmoong_pieces * g_moong_chilla.net_wt_gm;

  const egg_qty = clamp(Math.round(B.protein_g / egg.protein), 2, 4);

  const nw_suji_upma  = clamp(
    roundTo(b_cal_net / (suji_upma.calories / suji_upma.net_wt_gm), 10),
    suji_upma.net_wt_gm * 0.5,
    suji_upma.net_wt_gm * 2
  );
  const suji_upma_qty = clamp(roundToHalf(b_cal_net / suji_upma.calories), 0.5, 3);

  const nw_oats = clamp(
    roundTo(b_cal_net / (oats_cooked.calories / oats_cooked.net_wt_gm), 10),
    oats_cooked.net_wt_gm * 0.5,
    oats_cooked.net_wt_gm * 2
  );

  const white_bread_slices = clamp(Math.round(b_cal_net / 75), 1, 4);

  const b_paneer_qty = clamp(
    roundTo(Math.max(0, b_prot_after_curd) / paneer_prot_per_g, 10),
    30, 100
  );
  const b_tofu_qty = clamp(
    roundTo(Math.max(0, b_prot_after_curd) / tofu_prot_per_g, 10),
    30, 100
  );

  const dalia_cal_avail = b_cal_net - b_paneer_qty * paneer_cal_per_g;
  const dalia_veg_qty   = clamp(roundToHalf(dalia_cal_avail / dalia_khichadi.calories), 0.5, 3);
  const nw_dalia_veg    = Math.round(dalia_veg_qty * dalia_khichadi.net_wt_gm);

  const ragi_after_paneer = b_cal_after_curd - b_paneer_qty * paneer_cal_per_g;
  const ragi_pieces = clamp(Math.round(Math.max(1, ragi_after_paneer / ragi_chilla.calories)), 1, 4);
  const nw_ragi     = ragi_pieces * ragi_chilla.net_wt_gm;

  // ── LUNCH ───────────────────────────────────────────────────────────────────
  const l_cal_fixed  = CURD_CAL + SABZI_CAL;
  const l_prot_fixed = CURD_PROT + SABZI_PROT;
  const l_cal_avail  = l_cal_net - l_cal_fixed;
  const l_prot_avail = L.protein_g - l_prot_fixed;

  const chicken_cal_per_g  = chicken.calories / chicken.serving_quantity;
  const chicken_prot_per_g = chicken.protein  / chicken.serving_quantity;
  const wrice_cal_per_katori = white_rice.calories;

  const L_nw_chicken = clamp(roundTo(l_prot_avail / chicken_prot_per_g, 10), 60, 200);
  const l_wrice_after_chicken = l_cal_avail - L_nw_chicken * chicken_cal_per_g;
  const L_wrice_chicken = Math.max(0.5, roundToHalf(l_wrice_after_chicken / wrice_cal_per_katori));

  const L_nw_paneer = clamp(roundTo(l_prot_avail / paneer_prot_per_g, 10), 60, 200);
  const l_wrice_after_paneer = l_cal_avail - L_nw_paneer * paneer_cal_per_g;
  const L_wrice_paneer = Math.max(0.5, roundToHalf(l_wrice_after_paneer / wrice_cal_per_katori));

  const L_nw_tofu = clamp(roundTo(l_prot_avail / tofu_prot_per_g, 10), 60, 200);

  const rajma_cups_l = Math.max(0.5, roundToHalf(l_prot_avail / rajma.protein));
  const L_rajma_qty  = rajma_cups_l;
  const L_nw_rajma   = Math.round(rajma_cups_l * rajma.net_wt_gm);
  const l_wrice_after_rajma = l_cal_avail - rajma_cups_l * rajma.calories;
  const L_wrice_rajma = Math.max(0.5, roundToHalf(l_wrice_after_rajma / wrice_cal_per_katori));

  const chhole_cups_l = Math.max(0.5, roundToHalf(l_prot_avail / chhole.protein));
  const L_chhole_qty  = chhole_cups_l;
  const L_nw_chhole   = Math.round(chhole_cups_l * chhole.net_wt_gm);

  const dal_cups_l = Math.max(0.5, roundToHalf(l_prot_avail / dal.protein));
  const L_dal_qty  = dal_cups_l;
  const L_nw_dal   = Math.round(dal_cups_l * dal.net_wt_gm);

  const kchana_cups_l = Math.max(0.5, roundToHalf(l_prot_avail / kala_chana.protein));
  const L_kchana_qty  = kchana_cups_l;
  const L_nw_kchana   = Math.round(kchana_cups_l * 150);

  const L_wrice_qty = Math.max(0.5, roundToHalf((L_wrice_chicken + L_wrice_paneer + L_wrice_rajma) / 3));
  const L_nw_wrice  = Math.round(L_wrice_qty * 130);

  // ── DINNER ──────────────────────────────────────────────────────────────────
  const d_cal_fixed  = CURD_CAL + SABZI_CAL;
  const d_prot_fixed = CURD_PROT + SABZI_PROT;
  const d_cal_avail  = d_cal_net - d_cal_fixed;
  const d_prot_avail = D.protein_g - d_prot_fixed;

  const d_wheat_roti_qty =
    totalCal <= 1200 ? 1 :
    totalCal <= 1600 ? 2 : 3;
  const d_nw_wheat_roti = d_wheat_roti_qty * (wheat_roti.net_wt_gm > 0 ? wheat_roti.net_wt_gm : 40);

  const roti_cal  = d_wheat_roti_qty * wheat_roti.calories;
  const roti_prot = d_wheat_roti_qty * wheat_roti.protein;
  const d_cal_after_roti  = d_cal_avail - roti_cal;
  const d_prot_after_roti = d_prot_avail - roti_prot;

  const d_nw_chicken = clamp(roundTo(Math.max(60, d_prot_after_roti / chicken_prot_per_g), 10), 60, 200);
  const d_wrice_after_chicken = d_cal_after_roti - d_nw_chicken * chicken_cal_per_g;
  const d_wrice_chicken = Math.max(0.5, roundToHalf(d_wrice_after_chicken / wrice_cal_per_katori));

  const d_nw_paneer = clamp(roundTo(Math.max(60, d_prot_after_roti / paneer_prot_per_g), 10), 60, 200);
  const d_wrice_after_paneer = d_cal_after_roti - d_nw_paneer * paneer_cal_per_g;
  const d_wrice_paneer = Math.max(0.5, roundToHalf(d_wrice_after_paneer / wrice_cal_per_katori));

  const d_nw_tofu = clamp(roundTo(Math.max(60, d_prot_after_roti / tofu_prot_per_g), 10), 60, 200);

  const rajma_cups_d = Math.max(0.5, roundToHalf(d_prot_after_roti / rajma.protein));
  const d_rajma_qty  = rajma_cups_d;
  const d_nw_rajma   = Math.round(rajma_cups_d * rajma.net_wt_gm);
  const d_wrice_after_rajma = d_cal_after_roti - rajma_cups_d * rajma.calories;
  const d_wrice_rajma = Math.max(0.5, roundToHalf(d_wrice_after_rajma / wrice_cal_per_katori));

  const chhole_cups_d = Math.max(0.5, roundToHalf(d_prot_after_roti / chhole.protein));
  const d_chhole_qty  = chhole_cups_d;
  const d_nw_chhole   = Math.round(chhole_cups_d * chhole.net_wt_gm);

  const dal_cups_d = Math.max(0.5, roundToHalf(d_prot_after_roti / dal.protein));
  const d_dal_qty  = dal_cups_d;
  const d_nw_dal   = Math.round(dal_cups_d * dal.net_wt_gm);

  const kchana_cups_d = Math.max(0.5, roundToHalf(d_prot_after_roti / kala_chana.protein));
  const d_kchana_qty  = kchana_cups_d;
  const d_nw_kchana   = Math.round(kchana_cups_d * 150);

  const d_wrice_qty = Math.max(0.5, roundToHalf((d_wrice_chicken + d_wrice_paneer + d_wrice_rajma) / 3));
  const d_nw_wrice  = Math.round(d_wrice_qty * 130);

  return {
    ragi_qty:            String(ragi_pieces),
    nw_ragi_qty:         String(nw_ragi),
    besan_qty:            String(besan_pieces),
    nw_besan_qty:         String(nw_besan),
    gmoong_qty:           String(gmoong_pieces),
    nw_gmoong_qty:        String(nw_gmoong),
    egg_qty:              String(egg_qty),
    nw_oats_qty:          String(nw_oats),
    suji_upma_qty:        String(suji_upma_qty),
    nw_suji_upma_qty:     String(nw_suji_upma),
    white_bread:          String(white_bread_slices),
    b_paneer_qty:         String(b_paneer_qty),
    b_tofu_qty:           String(b_tofu_qty),
    dalia_veg_qty:        String(dalia_veg_qty),
    nw_dalia_veg_qty:     String(nw_dalia_veg),
    curd_qty:             "1",
    L_wrice_qty:          String(L_wrice_qty),
    L_nw_wrice_qty:       String(L_nw_wrice),
    L_rajma_qty:          String(L_rajma_qty),
    L_nw_rajma_qty:       String(L_nw_rajma),
    L_chhole_qty:         String(L_chhole_qty),
    L_nw_chhole_qty:      String(L_nw_chhole),
    L_dal_qty:            String(L_dal_qty),
    L_nw_dal_qty:         String(L_nw_dal),
    L_nw_chicken_qty:     String(L_nw_chicken),
    L_nw_paneer_qty:      String(L_nw_paneer),
    L_nw_tofu_qty:        String(L_nw_tofu),
    L_kchana_qty:         String(L_kchana_qty),
    L_nw_kchana_qty:      String(L_nw_kchana),
    sabzi_qty:            "2",
    d_wheat_roti_qty:     String(d_wheat_roti_qty),
    d_nw_wheat_roti_qty:  String(d_nw_wheat_roti),
    d_wrice_qty:          String(d_wrice_qty),
    d_nw_wrice_qty:       String(d_nw_wrice),
    d_rajma_qty:          String(d_rajma_qty),
    d_nw_rajma_qty:       String(d_nw_rajma),
    d_chhole_qty:         String(d_chhole_qty),
    d_nw_chhole_qty:      String(d_nw_chhole),
    d_dal_qty:            String(d_dal_qty),
    d_nw_dal_qty:         String(d_nw_dal),
    d_nw_chicken_qty:     String(d_nw_chicken),
    d_nw_paneer_qty:      String(d_nw_paneer),
    d_nw_tofu_qty:        String(d_nw_tofu),
    d_kchana_qty:         String(d_kchana_qty),
    d_nw_kchana_qty:      String(d_nw_kchana),
    Oil_qty_b:            String(oil_b),
    Oil_qty_l:            String(oil_l),
    Oil_qty_d:            String(oil_d),
    total_qty_oil:        String(total_oil),
  };
}

// ─── Core Calculation: Basic Veg ─────────────────────────────────────────────

function calcBasicVeg(
  meals: MealMacros[],
  foods: Record<string, FoodItem>
): Record<string, string> {
  // calcBasicNonVeg is safe here because REQUIRED_FOODS["basic_veg"] includes
  // both "tofu_raw" and "chicken" so foods[...] lookups inside it won't crash.
  const base = calcBasicNonVeg(meals, foods);

  const B = meals.find((m) => m.meal === "breakfast")!;
  const L = meals.find((m) => m.meal === "lunch")!;
  const D = meals.find((m) => m.meal === "dinner")!;
  const totalCal = B.calories + L.calories + D.calories;

  const { oil_l, oil_d } = calculateOilSplit(totalCal);
  const OIL_CAL_PER_TSP = foods["oil"].calories;

  const l_cal_net = L.calories - oil_l * OIL_CAL_PER_TSP;
  const d_cal_net = D.calories - oil_d * OIL_CAL_PER_TSP;

  const curd       = foods["curd"];
  const paneer     = foods["paneer"];
  const tofu       = foods["tofu_raw"];
  const sabzi      = foods["sabzi_cooked"];
  const white_rice = foods["white_rice"];
  const wheat_roti = foods["wheat_roti"];
  const rajma      = foods["rajma_cooked"];

  const CURD_CAL  = curd.calories;
  const CURD_PROT = curd.protein;
  const SABZI_CAL  = sabzi.calories * 2;
  const SABZI_PROT = sabzi.protein * 2;

  const paneer_cal_per_g  = paneer.calories / paneer.serving_quantity;
  const tofu_prot_per_g   = tofu.protein / tofu.serving_quantity;
  const tofu_cal_per_g    = tofu.calories / tofu.serving_quantity;
  const wrice_cal_per_katori = white_rice.calories;
  
  

  // ── Lunch ────────────────────────────────────────────────────────────────────
  const l_cal_fixed  = CURD_CAL + SABZI_CAL;
  const l_prot_fixed = CURD_PROT + SABZI_PROT;
  const l_cal_avail  = l_cal_net - l_cal_fixed;
  const l_prot_avail = L.protein_g - l_prot_fixed;

  const L_nw_tofu = clamp(roundTo(l_prot_avail / tofu_prot_per_g, 10), 60, 200);
  const l_wrice_after_tofu = l_cal_avail - L_nw_tofu * tofu_cal_per_g;
  const L_wrice_tofu = Math.max(0.5, roundToHalf(l_wrice_after_tofu / wrice_cal_per_katori));

  const L_nw_paneer = parseFloat(base.L_nw_paneer_qty);
  const l_wrice_after_paneer = l_cal_avail - L_nw_paneer * paneer_cal_per_g;
  const L_wrice_paneer = Math.max(0.5, roundToHalf(l_wrice_after_paneer / wrice_cal_per_katori));

  const rajma_cups_l = Math.max(0.5, roundToHalf(l_prot_avail / rajma.protein));
  const l_wrice_after_rajma = l_cal_avail - rajma_cups_l * rajma.calories;
  const L_wrice_rajma = Math.max(0.5, roundToHalf(l_wrice_after_rajma / wrice_cal_per_katori));

  const L_wrice_qty_veg = Math.max(0.5, roundToHalf((L_wrice_tofu + L_wrice_paneer + L_wrice_rajma) / 3));
  const L_nw_wrice_veg  = Math.round(L_wrice_qty_veg * 130);

  // ── Dinner ───────────────────────────────────────────────────────────────────
  const d_cal_fixed  = CURD_CAL + SABZI_CAL;
  const d_prot_fixed = CURD_PROT + SABZI_PROT;
  const d_cal_avail  = d_cal_net - d_cal_fixed;
  const d_prot_avail = D.protein_g - d_prot_fixed;

  const d_wheat_roti_qty =
    totalCal <= 1200 ? 1 :
    totalCal <= 1600 ? 2 : 3;
  const roti_cal  = d_wheat_roti_qty * wheat_roti.calories;
  const roti_prot = d_wheat_roti_qty * wheat_roti.protein;
  const d_cal_after_roti  = d_cal_avail - roti_cal;
  const d_prot_after_roti = d_prot_avail - roti_prot;

  const d_nw_tofu = clamp(roundTo(Math.max(60, d_prot_after_roti / tofu_prot_per_g), 10), 60, 200);
  const d_wrice_after_tofu = d_cal_after_roti - d_nw_tofu * tofu_cal_per_g;
  const d_wrice_tofu = Math.max(0.5, roundToHalf(d_wrice_after_tofu / wrice_cal_per_katori));

  const d_nw_paneer_base = parseFloat(base.d_nw_paneer_qty);
  const d_wrice_after_paneer = d_cal_after_roti - d_nw_paneer_base * paneer_cal_per_g;
  const d_wrice_paneer = Math.max(0.5, roundToHalf(d_wrice_after_paneer / wrice_cal_per_katori));

  const rajma_cups_d = Math.max(0.5, roundToHalf(d_prot_after_roti / rajma.protein));
  const d_wrice_after_rajma = d_cal_after_roti - rajma_cups_d * rajma.calories;
  const d_wrice_rajma = Math.max(0.5, roundToHalf(d_wrice_after_rajma / wrice_cal_per_katori));

  const d_wrice_qty_veg = Math.max(0.5, roundToHalf((d_wrice_tofu + d_wrice_paneer + d_wrice_rajma) / 3));
  const d_nw_wrice_veg  = Math.round(d_wrice_qty_veg * 130);

  return {
    ...base,
    L_wrice_qty:      String(L_wrice_qty_veg),
    L_nw_wrice_qty:   String(L_nw_wrice_veg),
    d_wrice_qty:      String(d_wrice_qty_veg),
    d_nw_wrice_qty:   String(d_nw_wrice_veg),
    L_nw_tofu_qty:    String(L_nw_tofu),
    d_nw_tofu_qty:    String(d_nw_tofu),
    // basic_veg template uses {{d_nw_Paneer_qty}} (capital P) — same value
    d_nw_Paneer_qty:  String(d_nw_paneer_base),
    // Zero out chicken/egg for veg plan
    L_nw_chicken_qty: "0",
    d_nw_chicken_qty: "0",
    egg_qty:          "0",
  };
}

// ─── Required Food IDs per Plan ───────────────────────────────────────────────
//
// KEY RULE: The veg calc functions call the nonveg base function first.
// That base function accesses foods["chicken"] and foods["tofu_raw"].
// So BOTH must be fetched for ALL 4 plans — otherwise the base call crashes
// with "Cannot read properties of undefined (reading 'calories')".

const REQUIRED_FOODS: Record<string, string[]> = {
  pcos_nonveg: [
    "oil", "curd", "besan_chilla", "g_moong_chilla", "egg", "sourdough_bread",
    "oats_cooked", "ragi_chilla", "paneer", "tofu_raw", "dalia_khichadi", "millet_upma",
    "brown_rice", "rajma_cooked", "chhole_cooked", "dal", "kala_chana",
    "sabzi_cooked", "chicken", "jowar_roti",
  ],
  pcos_veg: [
    "oil", "curd", "besan_chilla", "g_moong_chilla", "egg", "sourdough_bread",
    "oats_cooked", "ragi_chilla", "paneer", "tofu_raw", "dalia_khichadi", "millet_upma",
    "brown_rice", "rajma_cooked", "chhole_cooked", "dal", "kala_chana",
    "sabzi_cooked", "chicken", "jowar_roti",
    // chicken included so calcPcosNonVeg (called as base) doesn't crash
  ],
  basic_nonveg: [
    "oil", "curd", "besan_chilla", "g_moong_chilla", "egg",
    "oats_cooked", "ragi_chilla", "suji_upma", "paneer", "tofu_raw", "dalia_khichadi",
    "white_rice", "wheat_roti", "rajma_cooked", "chhole_cooked", "dal",
    "kala_chana", "sabzi_cooked", "chicken",
  ],
  basic_veg: [
    "oil", "curd", "besan_chilla", "g_moong_chilla", "egg",
    "oats_cooked", "ragi_chilla", "suji_upma", "paneer", "tofu_raw", "dalia_khichadi",
    "white_rice", "wheat_roti", "rajma_cooked", "chhole_cooked", "dal",
    "kala_chana", "sabzi_cooked", "chicken",
    // chicken included so calcBasicNonVeg (called as base) doesn't crash
  ],
};

// ─── Main Handler ─────────────────────────────────────────────────────────────

serve(async (req: Request) => {
  const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  };

  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const body: RequestBody = await req.json();
    const { plan_type, mobile_number, customer_name, email, input, meals } = body;

    if (!input || !meals || meals.length < 3) {
      return new Response(
        JSON.stringify({ success: false, error: "Missing input or meals. Pass the full output of supa_calculate_macros." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const normalizedPlan = (plan_type ?? "pcos_nonveg").toLowerCase();
    const requiredFoodIds = REQUIRED_FOODS[normalizedPlan] ?? REQUIRED_FOODS["pcos_nonveg"];

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase    = createClient(supabaseUrl, supabaseKey);

    const { data: foodRows, error: dbError } = await supabase
      .from("food_items")
      .select("food_id, food_name, calories, protein, carbs, fat, serving_quantity, serving_unit, net_wt_gm, food_state")
      .in("food_id", requiredFoodIds);

    if (dbError) {
      return new Response(
        JSON.stringify({ success: false, error: `DB error: ${dbError.message}` }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const foods: Record<string, FoodItem> = {};
    for (const row of foodRows as FoodItem[]) {
      foods[row.food_id] = row;
    }

    const missing = requiredFoodIds.filter((id) => !foods[id]);
    if (missing.length > 0) {
      return new Response(
        JSON.stringify({ success: false, error: `Missing food items in DB: ${missing.join(", ")}` }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    let quantities: Record<string, string>;
    switch (normalizedPlan) {
      case "pcos_veg":
        quantities = calcPcosVeg(meals, foods);
        break;
      case "basic_nonveg":
        quantities = calcBasicNonVeg(meals, foods);
        break;
      case "basic_veg":
        quantities = calcBasicVeg(meals, foods);
        break;
      default: // pcos_nonveg
        quantities = calcPcosNonVeg(meals, foods);
    }

    const result = {
      success: true,
      plan_type:       normalizedPlan,
      mobile_number:   mobile_number ?? "",
      customer_name:   customer_name ?? "",
      email:           email         ?? "",
      target_calories: String(input.target_calories),
      ...quantities,
    };

    return new Response(
      JSON.stringify(result),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (err) {
    return new Response(
      JSON.stringify({ success: false, error: String(err) }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
